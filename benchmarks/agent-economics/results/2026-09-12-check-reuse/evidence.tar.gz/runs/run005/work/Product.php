<?php final class Product { public function resolveByUid(): int { return 7; } public function run(): array { return [$this->resolveByUid(), 'findByUid']; } }

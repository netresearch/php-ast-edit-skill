<?php

declare(strict_types=1);

require __DIR__ . '/Product.php';

$product = new Product();
if ($product->run() !== [7, 'findByUid']
    || !method_exists($product, 'resolveByUid')
    || method_exists($product, 'findByUid')) {
    exit(1);
}

echo "OK: Product method rename
";

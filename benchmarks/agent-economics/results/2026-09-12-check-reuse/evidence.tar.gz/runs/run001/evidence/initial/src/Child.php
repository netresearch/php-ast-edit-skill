<?php

declare(strict_types=1);

namespace Pilot\CrossFile;

final class Child extends Base
{
    public function fetch(): int
    {
        return parent::fetch() + 2;
    }
}


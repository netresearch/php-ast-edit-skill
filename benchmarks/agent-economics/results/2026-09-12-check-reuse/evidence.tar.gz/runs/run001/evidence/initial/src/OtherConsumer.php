<?php

declare(strict_types=1);

namespace Pilot\CrossFile;

final class OtherConsumer
{
    public function run(Other $service): int
    {
        return $service->fetch();
    }
}


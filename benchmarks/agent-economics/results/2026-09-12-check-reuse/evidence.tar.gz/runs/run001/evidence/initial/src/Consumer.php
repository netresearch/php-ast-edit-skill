<?php

declare(strict_types=1);

namespace Pilot\CrossFile;

final class Consumer
{
    public function run(Contract $service): int
    {
        return $service->fetch();
    }

    public function title(): string
    {
        return 'fetch service';
    }
}


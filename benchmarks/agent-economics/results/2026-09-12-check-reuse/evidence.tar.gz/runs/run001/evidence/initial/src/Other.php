<?php

declare(strict_types=1);

namespace Pilot\CrossFile;

final class Other
{
    public function fetch(): int
    {
        return 7;
    }
}


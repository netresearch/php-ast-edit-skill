<?php

declare(strict_types=1);

namespace Pilot\CrossFile;

interface Contract
{
    public function load(): int;
}

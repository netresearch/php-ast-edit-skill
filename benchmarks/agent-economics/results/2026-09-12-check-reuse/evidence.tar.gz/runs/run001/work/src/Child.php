<?php

declare(strict_types=1);

namespace Pilot\CrossFile;

final class Child extends Base
{
    public function load(): int
    {
        return parent::load() + 2;
    }
}

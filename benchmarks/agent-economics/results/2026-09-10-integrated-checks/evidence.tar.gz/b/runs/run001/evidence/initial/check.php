<?php

declare(strict_types=1);

$failures = [];
$tree = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator(__DIR__, FilesystemIterator::SKIP_DOTS),
);

foreach ($tree as $file) {
    if ($file->getExtension() !== 'php' || $file->getPathname() === __FILE__) {
        continue;
    }

    try {
        token_get_all((string) file_get_contents($file->getPathname()), TOKEN_PARSE);
    } catch (ParseError $error) {
        $failures[] = $file->getPathname() . ': ' . $error->getMessage();
    }
}

if ($failures !== []) {
    echo implode("\n", $failures), "\n";

    exit(1);
}

echo "OK: every PHP file parses\n";

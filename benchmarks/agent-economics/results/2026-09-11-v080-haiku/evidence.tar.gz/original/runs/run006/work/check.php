<?php

declare(strict_types=1);

require __DIR__ . '/autoload.php';

$child = new Pilot\CrossFile\Child();
$method = 'load';
if ($child->$method() !== 42
    || (new Pilot\CrossFile\Other())->fetch() !== 7
    || (new Pilot\CrossFile\Consumer())->title() !== 'fetch service'
    || (new Pilot\CrossFile\Base())->description() !== 'base fetch service') {
    exit(1);
}


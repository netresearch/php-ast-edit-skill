<?php

declare(strict_types=1);

namespace Pilot\Simple;

/** A small greeting value object used by a command-line renderer. */
final class Greeting
{
    public function __construct(private readonly string $name)
    {
    }

    public function greeting(): string
    {
        return 'Welcome ' . $this->name;
    }

    public function initials(): string
    {
        return strtoupper($this->name[0]);
    }

    public function label(): string
    {
        return 'greeting';
    }

    public function asArray(): array
    {
        return [
            'name' => $this->name,
            'greeting' => $this->greeting(),
            'initials' => $this->initials(),
        ];
    }
}

function renderGreeting(string $name): array
{
    $greeting = new Greeting($name);

    return $greeting->asArray();
}

function renderLabel(): string
{
    return (new Greeting('Ada'))->label();
}

function renderInitials(string $name): string
{
    return (new Greeting($name))->initials();
}

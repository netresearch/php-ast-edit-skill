<?php

declare(strict_types=1);

require __DIR__ . '/Greeting.php';

$greeting = new Pilot\Simple\Greeting('Ada');
if (!in_array($greeting->greeting(), ['Hello Ada', 'Welcome Ada'], true)
    || $greeting->initials() !== 'A'
    || $greeting->label() !== 'greeting') {
    exit(1);
}


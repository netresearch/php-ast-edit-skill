<?php

declare(strict_types=1);

require __DIR__ . '/Cart.php';

$cart = new Pilot\Batch\Cart(10, 5);
if ($cart->summary() !== ['subtotal' => 15, 'tax' => 3, 'total' => 18]
    || $cart->propertyValue() !== 10
    || $cart->label() !== 'value') {
    exit(1);
}


<?php

declare(strict_types=1);

namespace Pilot\Batch;

/** A cart with three calculations that intentionally use the same local name. */
final class Cart
{
    public function __construct(
        private readonly int $price,
        private readonly int $fee,
    ) {
    }

    public function subtotal(): int
    {
        $amount = $this->price + $this->fee;

        return $amount;
    }

    public function tax(): int
    {
        $amount = intdiv($this->subtotal() * 2, 10);

        return $amount;
    }

    public function total(): int
    {
        $amount = $this->subtotal() + $this->tax();

        return $amount;
    }

    public function propertyValue(): int
    {
        return $this->price;
    }

    public function label(): string
    {
        return 'value';
    }

    public function summary(): array
    {
        return [
            'subtotal' => $this->subtotal(),
            'tax' => $this->tax(),
            'total' => $this->total(),
        ];
    }
}

function buildCart(): array
{
    return (new Cart(10, 5))->summary();
}

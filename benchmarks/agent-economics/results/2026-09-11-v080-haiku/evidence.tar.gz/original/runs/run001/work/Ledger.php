<?php

declare(strict_types=1);

namespace Pilot\Confusable;

/** Demonstrates a parameter capture beside a property and method of the same name. */
final class Ledger
{
    public function __construct(private readonly int $total)
    {
    }

    public function total(): int
    {
        return $this->total;
    }

    public function receipt(int $amount): array
    {
        $capture = static function (int $line) use ($amount): int {
            return $amount + $line;
        };
        $sum = $capture(3);

        return [
            'total' => $sum,
            'label' => 'total',
        ];
    }

    public function unchangedParameter(int $total): int
    {
        return $total + 1;
    }

    public function callableReceipt(int $total): int
    {
        $make = fn (int $line): int => $total + $line;

        return $make(2);
    }
}

function receiptValues(): array
{
    $ledger = new Ledger(100);

    return [
        $ledger->total(),
        $ledger->receipt(5),
        $ledger->unchangedParameter(5),
        $ledger->callableReceipt(5),
    ];
}


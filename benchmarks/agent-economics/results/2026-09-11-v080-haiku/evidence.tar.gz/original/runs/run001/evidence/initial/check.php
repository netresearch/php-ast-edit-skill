<?php

declare(strict_types=1);

require __DIR__ . '/Ledger.php';

$ledger = new Pilot\Confusable\Ledger(100);
if ($ledger->total() !== 100
    || $ledger->receipt(5)['total'] !== 8
    || $ledger->unchangedParameter(5) !== 6
    || $ledger->callableReceipt(5) !== 7) {
    exit(1);
}


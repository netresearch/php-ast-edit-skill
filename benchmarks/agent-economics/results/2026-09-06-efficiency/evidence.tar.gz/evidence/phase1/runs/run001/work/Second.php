<?php

final class Second
{
    public const VERSION = 2;
    public function id(): int
    {
        return 2;
    }
}

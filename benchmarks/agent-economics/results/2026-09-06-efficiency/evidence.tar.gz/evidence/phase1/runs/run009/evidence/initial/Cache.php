<?php

final class Cache
{
    public string $nonceCache = 'kept';
    public function getNonceCacheKey(): string
    {
        return 'kept';
    }
    public function key(): string
    {
        $nonce = '42';
        $f = function () use ($nonce) {
            return $nonce;
        };
        return 'nonce_' . $f();
    }
}

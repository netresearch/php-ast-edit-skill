<?php

final class Second
{
    public function id(): int
    {
        return 2;
    }
}

<?php

final class Second
{
    public function id(): int
    {
        return 2;
    }
    public const VERSION = 2;
}

<?php

final class First
{
    public function id(): int
    {
        return 1;
    }
}

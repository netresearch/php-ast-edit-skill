<?php

final class First
{
    public const VERSION = 2;

    public function id(): int
    {
        return 1;
    }
}

<?php

final class First
{
    public function id(): int
    {
        return 1;
    }
    public const VERSION = 2;
}

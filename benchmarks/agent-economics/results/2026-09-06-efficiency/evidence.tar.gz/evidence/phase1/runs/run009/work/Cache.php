<?php

final class Cache
{
    public string $nonceCache = 'kept';
    public function getNonceCacheKey(): string
    {
        return 'kept';
    }
    public function key(): string
    {
        $token = '42';
        $f = function () use ($token) {
            return $token;
        };
        return 'nonce_' . $f();
    }
}

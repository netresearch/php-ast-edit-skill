# Sanitized experiment evidence

These are sanitized derivatives, not byte-original native traces. See export-manifest.json for original/private and exported SHA-256 linkage, exact omissions, normalized paths, and native line mappings. Measurements and producer review statuses are preserved.

Campaign capture complete: true. This means every scheduled attempt has a captured measurement, including failures and timeouts; it does not mean complete native accounting or successful outcomes. Publication and independent export review remain pending.

Public TYPO3 fixtures retain GPL-2.0-or-later notices; license copies are in licenses/. Exact source commits, reconstruction descriptions and oracle limitations are in each pinned controller/benchmarks/tasks.json. Runtime/vendor binaries and private historical Claude sessions are excluded.

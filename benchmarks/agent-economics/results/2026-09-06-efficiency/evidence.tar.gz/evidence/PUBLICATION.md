# Portable publication attachments

The campaign export is unchanged. ancillary-manifest.json records the separate allowlist, original and exported hashes, path and assistant-role normalization, and license boundaries. reviews/review-manifest.json links the complete independent assistant reviews. Human acceptance remains as recorded.

Run `python3 tools/verify_public.py . --output /tmp/public-verification.json` from this evidence directory. It checks hashes, original links, native accounting and review coverage without original private paths. It imports the hash-verified archived parser; it never runs candidate commands or models. Validation of transformation fidelity against private originals is retained separately under validation/. Checksums are integrity links, not authenticity signatures.

The representation study records original byte counts, not model tokens; normalized path-bearing files can have different sizes. No raw-AST candidate arm was measured. To regenerate the public fixtures, supply the pinned public Git clones and engine checkout at the documented /source placeholders in tasks/build.py. Full TYPO3 application integration is not claimed.

Phase3 provenance uses two intentional runtime-inventory encodings: runtime_inventory_sha256 hashes compact sorted JSON, while this manifest hashes the indented file bytes. No inventory values change. Planning reservations are separate from native cost; missing terminal totals remain unknown.

Code and new helper scripts use MIT; documentation uses CC-BY-SA-4.0. Public TYPO3 source, including encoded reference source, retains GPL-2.0-or-later. See licenses/.

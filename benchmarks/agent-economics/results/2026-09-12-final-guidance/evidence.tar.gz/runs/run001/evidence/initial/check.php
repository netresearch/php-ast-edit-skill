<?php

declare(strict_types=1);

require __DIR__ . '/Catalog.php';

$catalog = new Evidence\Solo\Catalog();
$source = file_get_contents(__DIR__ . '/Catalog.php');
if ($source === false
    || $catalog->report() !== [23, 'findSku', ['findSku' => 'literal']]
    || !method_exists($catalog, 'resolveSku')
    || method_exists($catalog, 'findSku')
    || substr_count($source, 'function resolveSku') !== 1
    || substr_count($source, 'function findSku') !== 0
    || !str_contains($source, "'findSku',")
    || !str_contains($source, "'findSku' =>")) {
    exit(1);
}

echo "OK: Catalog method rename\n";

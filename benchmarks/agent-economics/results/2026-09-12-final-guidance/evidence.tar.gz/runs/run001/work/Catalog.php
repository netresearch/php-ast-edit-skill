<?php

declare(strict_types=1);

namespace Evidence\Solo;

final class Catalog
{
    public function resolveSku(): int
    {
        return 23;
    }

    public function report(): array
    {
        return [$this->resolveSku(), 'findSku', ['findSku' => 'literal']];
    }
}

<?php

declare(strict_types=1);

namespace Evidence\Network;

final class EmailTransport implements Transport
{
    public function deliver(): string
    {
        return 'email';
    }
}

<?php

declare(strict_types=1);

namespace Evidence\Network;

final class LegacyTransport
{
    public function deliver(): string
    {
        return 'legacy';
    }
}

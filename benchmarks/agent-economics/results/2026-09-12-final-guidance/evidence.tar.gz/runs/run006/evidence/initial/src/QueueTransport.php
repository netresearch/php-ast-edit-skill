<?php

declare(strict_types=1);

namespace Evidence\Network;

final class QueueTransport implements Transport
{
    public function deliver(): string
    {
        return 'queue';
    }
}

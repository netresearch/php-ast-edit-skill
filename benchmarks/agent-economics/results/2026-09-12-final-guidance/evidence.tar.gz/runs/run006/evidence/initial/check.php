<?php

declare(strict_types=1);

require __DIR__ . '/src/Transport.php';
require __DIR__ . '/src/EmailTransport.php';
require __DIR__ . '/src/QueueTransport.php';
require __DIR__ . '/src/Sender.php';
require __DIR__ . '/src/LegacyTransport.php';
require __DIR__ . '/src/LegacySender.php';

use Evidence\Network\EmailTransport;
use Evidence\Network\LegacySender;
use Evidence\Network\LegacyTransport;
use Evidence\Network\QueueTransport;
use Evidence\Network\Sender;

$sender = new Sender();
$legacySender = new LegacySender();
$transport = file_get_contents(__DIR__ . '/src/Transport.php');
$senderSource = file_get_contents(__DIR__ . '/src/Sender.php');
$config = file_get_contents(__DIR__ . '/config/channels.yaml');
if ($transport === false
    || $senderSource === false
    || $config === false
    || $sender->dispatch(new EmailTransport()) !== 'email'
    || $sender->dispatch(new QueueTransport()) !== 'queue'
    || !method_exists(new EmailTransport(), 'transmit')
    || method_exists(new EmailTransport(), 'deliver')
    || !method_exists(new QueueTransport(), 'transmit')
    || method_exists(new QueueTransport(), 'deliver')
    || $legacySender->dispatch(new LegacyTransport()) !== 'legacy'
    || !str_contains($transport, 'function transmit')
    || str_contains($transport, 'function deliver')
    || !str_contains($senderSource, '->transmit()')
    || str_contains($senderSource, '->deliver()')
    || !str_contains($config, "label: deliver\n")) {
    exit(1);
}

echo "OK: interface method rename\n";

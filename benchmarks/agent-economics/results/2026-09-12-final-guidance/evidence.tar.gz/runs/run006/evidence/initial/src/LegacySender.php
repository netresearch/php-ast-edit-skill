<?php

declare(strict_types=1);

namespace Evidence\Network;

final class LegacySender
{
    public function dispatch(LegacyTransport $transport): string
    {
        return $transport->deliver();
    }
}

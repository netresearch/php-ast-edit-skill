<?php

declare(strict_types=1);

namespace Evidence\Network;

interface Transport
{
    public function transmit(): string;
}

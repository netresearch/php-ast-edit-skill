<?php

declare(strict_types=1);

namespace Evidence\Network;

final class EmailTransport implements Transport
{
    public function transmit(): string
    {
        return 'email';
    }
}

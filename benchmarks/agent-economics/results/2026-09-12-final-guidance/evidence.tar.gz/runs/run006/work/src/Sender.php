<?php

declare(strict_types=1);

namespace Evidence\Network;

final class Sender
{
    public function dispatch(Transport $transport): string
    {
        return $transport->transmit();
    }
}

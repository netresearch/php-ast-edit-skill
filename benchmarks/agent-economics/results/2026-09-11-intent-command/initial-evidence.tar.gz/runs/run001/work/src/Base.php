<?php

declare(strict_types=1);

namespace Pilot\CrossFile;

class Base implements Contract
{
    public function load(): int
    {
        return 40;
    }

    public function description(): string
    {
        return 'base fetch service';
    }
}


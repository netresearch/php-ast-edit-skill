<?php
namespace Example;
class Provider { public function load(): int { return 11; } }
class Other { public function fetch(): int { return 22; } }

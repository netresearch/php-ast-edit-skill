<?php
namespace Example;
// 😀 Keep fetch in unrelated text.
function run33(Provider $second, Other $first): array { return [$second->load(), $first->fetch()]; }

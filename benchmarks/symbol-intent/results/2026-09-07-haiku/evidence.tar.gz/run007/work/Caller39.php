<?php
namespace Example;
// 😀 Keep fetch in unrelated text.
function run39(Provider $second, Other $first): array { return [$second->load(), $first->fetch()]; }

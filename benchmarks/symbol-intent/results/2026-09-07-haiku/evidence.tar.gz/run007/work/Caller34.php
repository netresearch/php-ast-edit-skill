<?php
namespace Example;
// 😀 Keep fetch in unrelated text.
function run34(Provider $first, Other $second): array { return [$first->load(), $second->fetch()]; }

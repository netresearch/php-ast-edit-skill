#!/usr/bin/env python3
"""Export a completed 30-run public-fixture campaign using explicit scopes.

This script reads evidence only. It never runs models, controllers, source PHP,
or summarization commands. Output contains no symlinks, PHARs, vendor, or Git
metadata. File contents are preserved verbatim rather than redacted.
"""

import argparse
import gzip
import hashlib
import io
import json
import os
import re
import stat
import sys
import tarfile
from pathlib import Path

ATTEMPTS = 30
RUN_ID = re.compile(r"run[0-9]{3}\Z")
BLOCKED_PARTS = {".git", "vendor", "node_modules", "__pycache__"}
GPL_LICENSE_SHA256 = "edaef632cbb643e4e7a221717a6c441a4c1a7c918e6e4d56debc3d8739b233f6"
SOURCE_HELPERS = Path("source/benchmarks/symbol-intent")
NATIVE_HELPER = Path("source/benchmarks/agent-economics/efficiency/native.py")
RECEIPT_DIRS = (Path("check-receipts"),)


class ExportError(ValueError):
    pass


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


def regular(path, root):
    """Check ancestors as well as the leaf without following a symlink."""
    relative = path.relative_to(root)
    if any(part in BLOCKED_PARTS for part in relative.parts):
        return False
    if path.name.lower().endswith(".phar"):
        return False
    current = root
    for part in relative.parts:
        current /= part
        try:
            mode = current.lstat().st_mode
        except FileNotFoundError:
            return False
        if stat.S_ISLNK(mode):
            return False
    return stat.S_ISREG(path.lstat().st_mode)


def required(path, root):
    if not regular(path, root):
        raise ExportError(
            "Required regular evidence file is absent: " + str(path.relative_to(root))
        )
    return path.read_bytes()


def document(path, root):
    try:
        value = json.loads(required(path, root))
    except (UnicodeError, json.JSONDecodeError) as error:
        raise ExportError(
            "Invalid JSON evidence: " + str(path.relative_to(root))
        ) from error
    if not isinstance(value, dict):
        raise ExportError("Evidence object expected: " + str(path.relative_to(root)))
    return value


def children(directory, root):
    if directory.is_symlink() or not directory.is_dir():
        return []
    return sorted(path for path in directory.iterdir() if regular(path, root))


def work_files(directory, root):
    if directory.is_symlink() or not directory.is_dir():
        raise ExportError("Run work directory is absent or a symlink")
    result = []

    def unreadable(error):
        raise error

    for base, names, files in os.walk(directory, followlinks=False, onerror=unreadable):
        current = Path(base)
        names[:] = sorted(
            name
            for name in names
            if name not in BLOCKED_PARTS and not (current / name).is_symlink()
        )
        result.extend(
            current / name for name in sorted(files) if regular(current / name, root)
        )
    return result


def collect(campaign):
    config_bytes = required(campaign / "config.json", campaign)
    config = document(campaign / "config.json", campaign)
    if config.get("experiment") != "real-php-verification-v1":
        raise ExportError("Not the real-php-verification-v1 campaign")
    if required(campaign / "config.sha256", campaign).decode().strip() != sha(
        config_bytes
    ):
        raise ExportError("Frozen config checksum mismatch")
    complete = document(campaign / "complete.json", campaign)
    schedule = config.get("schedule")
    if (
        not isinstance(schedule, list)
        or len(schedule) != ATTEMPTS
        or complete.get("attempts") != ATTEMPTS
    ):
        raise ExportError("A completed 30-run configuration is required")
    ids = [row.get("id") if isinstance(row, dict) else None for row in schedule]
    if (
        any(not isinstance(name, str) or not RUN_ID.fullmatch(name) for name in ids)
        or len(set(ids)) != ATTEMPTS
    ):
        raise ExportError("Schedule must name 30 unique runNNN directories")

    files = set(children(campaign, campaign))
    helpers = children(campaign / SOURCE_HELPERS, campaign)
    if not helpers:
        raise ExportError("Frozen symbol-intent helper sources are absent")
    files.update(helpers)
    required(campaign / NATIVE_HELPER, campaign)
    files.add(campaign / NATIVE_HELPER)

    for name in sorted(ids):
        run = campaign / name
        measurement = document(run / "measurement.json", campaign)
        if measurement.get("id") != name or measurement.get("config_sha256") != sha(
            config_bytes
        ):
            raise ExportError(
                "Measurement does not match its frozen run/config: " + name
            )
        required(run / "native.jsonl", campaign)
        license_bytes = required(run / "work/LICENSE", campaign)
        if sha(license_bytes) != GPL_LICENSE_SHA256:
            raise ExportError("Pinned public GPL license is absent or changed: " + name)
        files.update(children(run, campaign))
        files.update(work_files(run / "work", campaign))
        state = run / "state"
        files.update(
            path
            for path in children(state, campaign)
            if path.suffix in (".json", ".consumed")
        )
        if state.is_dir() and not state.is_symlink():
            for resolver in sorted(state.glob("resolver-*")):
                files.update(children(resolver, campaign))
        for relative in RECEIPT_DIRS:
            files.update(
                path
                for path in children(run / relative, campaign)
                if path.suffix == ".json"
            )

    payload = {
        path.relative_to(campaign).as_posix(): path.read_bytes()
        for path in sorted(files)
    }
    payload["exporter/php-real-export.py"] = Path(__file__).read_bytes()
    payload["exporter/php-real-verify-export.py"] = (
        Path(__file__).with_name("php-real-verify-export.py").read_bytes()
    )
    return config, payload


def archive_bytes(payload):
    buffer = io.BytesIO()
    with (
        gzip.GzipFile(
            filename="", fileobj=buffer, mode="wb", compresslevel=9, mtime=0
        ) as compressed,
        tarfile.open(
            fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT
        ) as archive,
    ):
        for name, data in sorted(payload.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
    return buffer.getvalue()


def verify_archive(data, manifest):
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        members = archive.getmembers()
        if (
            len(members) != len(manifest)
            or {member.name for member in members} != manifest.keys()
        ):
            raise ExportError("Archive member inventory differs from manifest")
        for member in members:
            if (
                not member.isfile()
                or member.name.startswith("/")
                or ".." in Path(member.name).parts
            ):
                raise ExportError("Unexpected archive member kind or path")
            if sha(archive.extractfile(member).read()) != manifest[member.name]:
                raise ExportError("Archived file hash mismatch: " + member.name)


def export(campaign, destination):
    campaign, destination = Path(campaign), Path(destination)
    if campaign.is_symlink() or not campaign.is_dir():
        raise ExportError("Campaign must be a regular directory")
    campaign = campaign.resolve()
    if destination.is_symlink() or destination.resolve().is_relative_to(campaign):
        raise ExportError("Destination must be outside the campaign")
    if destination.exists():
        raise ExportError("Destination must not already exist")
    config, payload = collect(campaign)
    manifest = {name: sha(data) for name, data in sorted(payload.items())}
    compressed = archive_bytes(payload)
    verify_archive(compressed, manifest)
    outputs = {
        "evidence.tar.gz": compressed,
        "evidence-manifest.json": encode(manifest),
    }
    # The controller owns summary naming and computation. Preserve any existing
    # real* summary/runs report verbatim without invoking its summarizer.
    report_names = [
        name
        for name in payload
        if "/" not in name and re.fullmatch(r"real[^/]*(?:summary|runs)\.json", name)
    ]
    for name in sorted(report_names):
        outputs[name] = payload[name]
    outputs["SHA256SUMS"] = "".join(
        f"{sha(data)}  {name}\n" for name, data in sorted(outputs.items())
    ).encode()
    destination.mkdir(parents=True, exist_ok=False)
    for name, data in outputs.items():
        (destination / name).write_bytes(data)
    return {
        "ok": True,
        "attempts": len(config["schedule"]),
        "files": len(payload),
        "archive_bytes": len(compressed),
        "archive_sha256": sha(compressed),
        "reports": sorted(report_names),
        "destination": str(destination.resolve()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--campaign", required=True, type=Path)
    parser.add_argument("--destination", required=True, type=Path)
    args = parser.parse_args()
    try:
        result = export(args.campaign, args.destination)
    except (ExportError, OSError, UnicodeError) as error:
        result = {"ok": False, "error": str(error)}
    print(json.dumps(result, sort_keys=True))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())

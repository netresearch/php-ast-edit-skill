#!/usr/bin/env python3
"""Verify a trusted campaign export and recompute its archived analysis offline.

Imports the archived Python controller/accounting helpers after checking their
frozen hashes. Does not invoke models, PHP, PHARs, Git, or the campaign runner.
Recorded PHPUnit results are checked against final manifests, not re-executed.
"""

import argparse
import hashlib
import importlib
import io
import json
import math
import re
import sys
import tarfile
import tempfile
from pathlib import Path

BLOCKED = {".git", "vendor", "node_modules", "__pycache__"}


class VerificationError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise VerificationError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def safe_name(name):
    path = Path(name)
    return (
        isinstance(name, str)
        and name != ""
        and not path.is_absolute()
        and path.as_posix() == name
        and ".." not in path.parts
        and not any(part in BLOCKED for part in path.parts)
        and not name.lower().endswith(".phar")
    )


def unpack(export, root):
    checksums = {}
    for line in (export / "SHA256SUMS").read_text().splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  ([^/]+)", line)
        require(match is not None, "Malformed payload checksum line")
        digest, name = match.groups()
        require(
            safe_name(name) and name not in checksums,
            "Invalid or repeated payload name",
        )
        path = export / name
        require(
            not path.is_symlink() and path.is_file(), "Missing regular payload: " + name
        )
        require(sha(path.read_bytes()) == digest, "Payload checksum mismatch: " + name)
        checksums[name] = digest
    require(
        {"evidence.tar.gz", "evidence-manifest.json"} <= checksums.keys(),
        "Required payload checksums absent",
    )
    manifest = read_json(export / "evidence-manifest.json")
    require(
        isinstance(manifest, dict) and manifest, "Empty or malformed evidence manifest"
    )
    data = (export / "evidence.tar.gz").read_bytes()
    require(data[4:8] == b"\x00\x00\x00\x00", "Gzip timestamp is not deterministic")
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        members = archive.getmembers()
        require(
            len(members) == len(manifest)
            and {m.name for m in members} == manifest.keys(),
            "Archive inventory differs from manifest",
        )
        for member in members:
            require(member.isfile() and safe_name(member.name), "Unsafe archive member")
            content = archive.extractfile(member).read()
            require(
                sha(content) == manifest[member.name],
                "Archived hash mismatch: " + member.name,
            )
            destination = root / member.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(content)
    for name in ("real-summary.json", "real-runs.json"):
        require(name in manifest, "Controller report absent: " + name)
        if name in checksums:
            require(
                (export / name).read_bytes() == (root / name).read_bytes(),
                "Outer and archived report differ: " + name,
            )
    return checksums, manifest


def normalized_checks(checks):
    # The controller records absolute paths only for malformed receipt errors;
    # relocation changes the prefix, not the receipt basename or parser error.
    return {
        **checks,
        "receipt_errors": [
            {**error, "path": Path(error["path"]).name}
            for error in checks.get("receipt_errors", [])
        ],
    }


def verify_observations(events, record, original_work, postcheck, entrypoint):
    # The extracted directory differs from the candidate's original workspace.
    # Match the assigned executable in the trace, never its relocated pathname.
    command = str(original_work.parent / "rename-tool")
    if record.get("accounting_error") or not record.get("native"):
        continuation = postcheck.unavailable_postcheck(
            "Native accounting unavailable; trace may be incomplete"
        )
        preparation = entrypoint.unavailable(
            "Native accounting unavailable; trace may be incomplete"
        )
    else:
        continuation = postcheck.post_calls(events, command)
        preparation = entrypoint.pre_calls(events, command)
    require(
        continuation == record.get("postcheck"),
        "Post-rename observations differ: " + record["id"],
    )
    require(
        preparation == record.get("precheck"),
        "Pre-rename observations differ: " + record["id"],
    )


def analyze(root, manifest):
    config = read_json(root / "config.json")
    config_hash = sha((root / "config.json").read_bytes())
    require(
        (root / "config.sha256").read_text().strip() == config_hash,
        "Frozen config hash mismatch",
    )
    require(
        config.get("experiment") == "real-php-entrypoint-v1",
        "Unexpected campaign identity",
    )
    require(
        read_json(root / "complete.json").get("attempts") == 20,
        "Campaign is not complete",
    )
    source_manifest = config.get("source_manifest", {})
    source_files = {
        name.removeprefix("source/"): value
        for name, value in manifest.items()
        if name.startswith("source/")
    }
    require(source_files, "No archived analysis sources")
    require(
        all(source_manifest.get(name) == value for name, value in source_files.items()),
        "Archived source differs from frozen source manifest",
    )

    # This is explicitly the frozen local benchmark's analysis code. The command
    # line entrypoints and all runtime/model execution functions remain unused.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root / "source/benchmarks/symbol-intent"))
    study = importlib.import_module("real_pilot")
    fixture = importlib.import_module("real_fixture")
    accounting = importlib.import_module("accounting")
    native = importlib.import_module("native")
    postcheck = importlib.import_module("postcheck_pilot")
    entrypoint = importlib.import_module("entrypoint_trial")
    require(
        config.get("phpunit_sha256") == fixture.PHPUNIT_SHA256,
        "Recorded PHPUnit pin mismatch",
    )
    require(
        config.get("fixture_source_commit") == fixture.SOURCE_COMMIT,
        "Public source pin mismatch",
    )
    schedule = config.get("schedule", [])
    require(
        [{k: v for k, v in row.items() if k != "frozen"} for row in schedule]
        == study.schedule(config["experiment"]),
        "Frozen 20-run schedule differs from controller",
    )
    records = []
    for row in schedule:
        run = root / row["id"]
        for name, digest in row.get("frozen", {}).items():
            require(
                safe_name(name) and sha((run / name).read_bytes()) == digest,
                "Frozen run input drift: " + row["id"] + "/" + name,
            )
        record = read_json(run / "measurement.json")
        require(
            all(record.get(key) == value for key, value in row.items()),
            "Measurement treatment drift: " + row["id"],
        )
        require(
            record.get("config_sha256") == config_hash,
            "Measurement config drift: " + row["id"],
        )
        events, malformed = native.read_events(run / "native.jsonl")
        require(not malformed, "Malformed native trace: " + row["id"])
        ledger = accounting.summarize(events, config["model"])
        require(ledger == record.get("native"), "Native ledger differs: " + row["id"])
        starts = [
            event
            for event in events
            if event.get("type") == "system" and event.get("subtype") == "init"
        ]
        require(len(starts) == 1, "Expected one native initialization: " + row["id"])
        original_work = Path(starts[0]["cwd"])
        require(
            original_work.is_absolute()
            and original_work.name == "work"
            and original_work.parent.name == row["id"],
            "Native workspace identity differs: " + row["id"],
        )
        verify_observations(events, record, original_work, postcheck, entrypoint)
        final = fixture.snapshot(run / "work")
        require(
            final == read_json(run / "final.json"),
            "Final fixture differs from recorded snapshot: " + row["id"],
        )
        checks = study.candidate_checks(run, final)
        require(
            normalized_checks(checks)
            == normalized_checks(record.get("candidate_checks", {})),
            "Candidate receipt summary differs: " + row["id"],
        )
        initial = read_json(run / "initial.json")
        oracle = fixture.oracle(
            run / "work",
            allowed_extras={study.PROJECT_CONFIG: initial[study.PROJECT_CONFIG]},
        )
        require(
            oracle == record.get("oracle"), "Exact-scope oracle differs: " + row["id"]
        )
        outcome = study.outcomes(
            record, ledger, oracle, record.get("hidden_behavior", {}), checks, final
        )
        require(
            outcome == record.get("outcome"),
            "Outcome differs from recorded tests and final bytes: " + row["id"],
        )
        records.append(record)
    require(
        len(records) == 20 and records == read_json(root / "real-runs.json"),
        "Published run ledger differs from measurements",
    )
    summary = {
        **study.summarize_records(records, config["experiment"]),
        "config_sha256": config_hash,
    }
    require(
        summary == read_json(root / "real-summary.json"),
        "Published summary differs from archived measurements",
    )
    require(
        math.isclose(
            read_json(root / "complete.json").get("native_list_price_usd"),
            summary["known_native_list_price_usd"],
            rel_tol=1e-12,
            abs_tol=1e-12,
        ),
        "Completed spend differs from native ledgers",
    )
    return {
        "attempts": len(records),
        "native_ledgers_verified": len(records),
        "pre_call_observations_verified": len(records),
        "known_pre_call_counts": sum(
            record["precheck"]["preceding_tool_calls"] is not None for record in records
        ),
        "candidate_final_tests_verified": sum(
            record["outcome"]["candidate_verified_final"] for record in records
        ),
        "exact_scope_correct": sum(
            record["outcome"]["exact_scope_correct"] for record in records
        ),
        "summary_matches": True,
        "archived_source_files_verified": len(source_files),
        "hidden_phpunit": "Recorded results checked against final manifests; tests not rerun because PHAR binaries are excluded",
    }


def verify(export):
    export = Path(export)
    require(
        not export.is_symlink() and export.is_dir(),
        "Export must be a regular directory",
    )
    with tempfile.TemporaryDirectory(
        prefix="php-entrypoint-export-verify-"
    ) as directory:
        root = Path(directory)
        checksums, manifest = unpack(export, root)
        result = analyze(root, manifest)
    return {"ok": True, "archive_sha256": checksums["evidence.tar.gz"], **result}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--export", required=True, type=Path)
    args = parser.parse_args()
    try:
        result = verify(args.export)
    except (
        ValueError,
        OSError,
        KeyError,
        TypeError,
        StopIteration,
        tarfile.TarError,
        ImportError,
    ) as error:
        result = {"ok": False, "error": str(error)}
    print(json.dumps(result, sort_keys=True))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
